import LegalPage from "@/components/LegalPage";

export default function PrivacyPolicyPage() {
  return <LegalPage title="Privacy Policy" contentKey="privacyPolicy" />;
}