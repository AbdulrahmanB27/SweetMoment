import LegalPage from "@/components/LegalPage";

export default function TermsOfServicePage() {
  return <LegalPage title="Terms of Service" contentKey="termsOfService" />;
}