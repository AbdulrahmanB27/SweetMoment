import DynamicProduct from "./DynamicProduct";

export default function DebugChocolate() {
  return <DynamicProduct id="6" />;
}