import LegalPage from "@/components/LegalPage";

export default function ShippingPolicyPage() {
  return <LegalPage title="Shipping Policy" contentKey="shippingPolicy" />;
}