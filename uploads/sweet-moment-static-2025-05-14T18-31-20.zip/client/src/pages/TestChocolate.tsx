import DynamicProduct from "./DynamicProduct";

export default function TestChocolate() {
  return <DynamicProduct id="3" />;
}