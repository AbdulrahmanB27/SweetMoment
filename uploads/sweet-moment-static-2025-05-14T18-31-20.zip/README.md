# Sweet Moment Static Site

This is a static version of the Sweet Moment website generated on 5/14/2025, 6:31:21 PM.

## Deployment Instructions

1. Extract all files from this ZIP archive
2. Deploy to a static hosting service like GitHub Pages
3. For GitHub Pages:
   - Create a new repository on GitHub
   - Push these files to the repository
   - Go to Settings > Pages and select the main branch for deployment

## Configuration

- Base URL: /SweetMoment/
- Generated: 2025-05-14T18:31:21.275Z

For more details, see the GITHUB_PAGES_DEPLOYMENT_GUIDE.md file.
